"""
backtest_engine.py
===================
Step 2 of the build: takes a history of (signal_label, expiration_week daily
prices) observations and produces the day-of-week conditional return table,
with proper statistical guardrails (small-N warnings, t-tests, multiple
comparison correction, out-of-sample split).

This is deliberately decoupled from signal_engine.py's live chain-snapshot
logic: here you feed in a tidy historical dataset (one row per underlying
per expiration-week, with the signal label already computed at N-2/N-3 weeks
prior, plus that week's realized daily returns). How you assemble that
history (batch-run signal_engine.py over historical snapshots) is a data
pipeline exercise specific to whatever vendor data you have -- this module
starts from the assembled table so you can validate the STATISTICS
independent of your data source.

Expected input schema (one row per underlying x expiration-week):

    underlying        str
    expiration_date   date
    signal_label      str   (e.g. "bullish-stable", from classify_quadrant)
    signal_date       date  (when the signal was computed, N-2/3 weeks prior)
    mon_ret           float (or np.nan if market holiday that week)
    tue_ret           float
    wed_ret           float
    thu_ret           float
    fri_ret           float
    week_range_pct    float ((High-Low)/Open across the expiration week)
    pinned_near_wall  bool  (closed within X% of GEX wall / max pain strike)
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats


DAY_COLS = ["mon_ret", "tue_ret", "wed_ret", "thu_ret", "fri_ret"]


# ---------------------------------------------------------------------------
# Core conditional summary table
# ---------------------------------------------------------------------------

def build_conditional_table(history: pd.DataFrame) -> pd.DataFrame:
    """
    Group by signal_label and compute mean/std/N for each day of expiration
    week, plus average weekly range and % of weeks that pinned near a wall.
    """
    rows = []
    for label, grp in history.groupby("signal_label"):
        row = {"signal_label": label, "n_weeks": len(grp)}
        for col in DAY_COLS:
            row[f"{col}_mean"] = grp[col].mean()
            row[f"{col}_std"] = grp[col].std(ddof=1)
        row["avg_week_range_pct"] = grp["week_range_pct"].mean()
        row["pct_pinned_near_wall"] = grp["pinned_near_wall"].mean() * 100
        rows.append(row)
    out = pd.DataFrame(rows).sort_values("signal_label").reset_index(drop=True)
    return out


# ---------------------------------------------------------------------------
# Statistical significance testing per (label, day) cell
# ---------------------------------------------------------------------------

def significance_tests(history: pd.DataFrame, alpha: float = 0.05) -> pd.DataFrame:
    """
    For each (signal_label, day) cell, run a one-sample t-test against a
    null of zero mean return. Apply Benjamini-Hochberg FDR correction across
    all cells tested simultaneously (since you're running signal_label x day
    combinations, that's a real multiple-comparisons problem).

    Returns a tidy table with raw p-values, FDR-adjusted p-values, and a
    flag for which cells survive correction.
    """
    records = []
    for label, grp in history.groupby("signal_label"):
        n = len(grp)
        for col in DAY_COLS:
            vals = grp[col].dropna().values
            if len(vals) < 3:
                records.append({
                    "signal_label": label, "day": col, "n": len(vals),
                    "mean_ret": np.nan, "t_stat": np.nan, "p_value": np.nan,
                    "note": "n<3, insufficient for t-test",
                })
                continue
            t_stat, p_val = stats.ttest_1samp(vals, popmean=0.0)
            records.append({
                "signal_label": label, "day": col, "n": len(vals),
                "mean_ret": vals.mean(), "t_stat": t_stat, "p_value": p_val,
                "note": "n<30, treat as directional only" if len(vals) < 30 else "",
            })

    result = pd.DataFrame(records)

    # Benjamini-Hochberg FDR correction across all valid p-values
    valid = result["p_value"].notna()
    p_vals = result.loc[valid, "p_value"].values
    if len(p_vals) > 0:
        order = np.argsort(p_vals)
        ranked = p_vals[order]
        m = len(p_vals)
        bh_adj = ranked * m / (np.arange(m) + 1)
        # enforce monotonicity (standard BH step-up correction)
        bh_adj = np.minimum.accumulate(bh_adj[::-1])[::-1]
        bh_adj = np.clip(bh_adj, 0, 1)
        adj_full = np.empty(m)
        adj_full[order] = bh_adj
        result.loc[valid, "p_value_fdr_adjusted"] = adj_full
        result["significant_after_fdr"] = result["p_value_fdr_adjusted"] < alpha
    else:
        result["p_value_fdr_adjusted"] = np.nan
        result["significant_after_fdr"] = False

    return result


# ---------------------------------------------------------------------------
# Bootstrap confidence intervals (more robust than t-test with small/skewed N)
# ---------------------------------------------------------------------------

def bootstrap_ci(values: np.ndarray, n_boot: int = 5000, ci: float = 0.95, seed: int = 42) -> tuple[float, float, float]:
    """Returns (mean, lower_ci, upper_ci) via percentile bootstrap."""
    rng = np.random.default_rng(seed)
    values = values[~np.isnan(values)]
    if len(values) == 0:
        return (np.nan, np.nan, np.nan)
    boot_means = np.array([
        rng.choice(values, size=len(values), replace=True).mean()
        for _ in range(n_boot)
    ])
    lower = np.percentile(boot_means, (1 - ci) / 2 * 100)
    upper = np.percentile(boot_means, (1 + ci) / 2 * 100)
    return (values.mean(), lower, upper)


def bootstrap_table(history: pd.DataFrame, n_boot: int = 5000) -> pd.DataFrame:
    records = []
    for label, grp in history.groupby("signal_label"):
        for col in DAY_COLS:
            mean, lo, hi = bootstrap_ci(grp[col].values, n_boot=n_boot)
            records.append({
                "signal_label": label, "day": col, "n": grp[col].notna().sum(),
                "mean_ret": mean, "ci_lower": lo, "ci_upper": hi,
                "ci_excludes_zero": (lo > 0) or (hi < 0) if not np.isnan(lo) else False,
            })
    return pd.DataFrame(records)


# ---------------------------------------------------------------------------
# Out-of-sample split
# ---------------------------------------------------------------------------

def train_test_split_by_date(history: pd.DataFrame, holdout_frac: float = 0.25) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Time-based split (NOT random) -- holds back the most recent observations
    as true out-of-sample. Random splitting would leak information since
    nearby weeks are correlated (autocorrelated vol regimes).
    """
    history_sorted = history.sort_values("expiration_date").reset_index(drop=True)
    cutoff_idx = int(len(history_sorted) * (1 - holdout_frac))
    train = history_sorted.iloc[:cutoff_idx].reset_index(drop=True)
    test = history_sorted.iloc[cutoff_idx:].reset_index(drop=True)
    return train, test


def validate_out_of_sample(history: pd.DataFrame, holdout_frac: float = 0.25) -> pd.DataFrame:
    """
    Compares in-sample vs out-of-sample mean returns per (label, day) cell.
    A pattern that reverses sign or collapses toward zero out-of-sample is a
    red flag for overfitting.
    """
    train, test = train_test_split_by_date(history, holdout_frac)
    train_table = build_conditional_table(train)
    test_table = build_conditional_table(test)

    records = []
    for _, row in train_table.iterrows():
        label = row["signal_label"]
        test_row = test_table[test_table["signal_label"] == label]
        for col in DAY_COLS:
            train_mean = row[f"{col}_mean"]
            test_mean = test_row[f"{col}_mean"].values[0] if not test_row.empty else np.nan
            same_sign = (np.sign(train_mean) == np.sign(test_mean)) if not np.isnan(test_mean) else False
            records.append({
                "signal_label": label, "day": col,
                "train_mean": train_mean, "test_mean": test_mean,
                "same_sign_oos": same_sign,
                "train_n": row["n_weeks"],
                "test_n": test_row["n_weeks"].values[0] if not test_row.empty else 0,
            })
    return pd.DataFrame(records)


# ---------------------------------------------------------------------------
# Self-test with synthetic historical data
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    from datetime import date, timedelta

    rng = np.random.default_rng(7)
    labels = ["bullish-stable", "bullish-volatile", "bearish-stable", "bearish-volatile"]

    # true (but small) effects baked in, plus noise -- to demonstrate the
    # pipeline recovers a plausible pattern and correctly flags weak cells
    true_effects = {
        "bullish-stable":   [0.0010, 0.0006, 0.0004, 0.0002, -0.0001],
        "bullish-volatile": [0.0030, 0.0045, -0.0015, 0.0020, 0.0008],
        "bearish-stable":   [-0.0008, -0.0005, -0.0003, -0.0002, 0.0001],
        "bearish-volatile": [-0.0035, -0.0040, 0.0010, -0.0025, -0.0012],
    }

    rows = []
    start = date(2021, 1, 8)
    for i in range(200):  # 200 synthetic expiration weeks across ~4 underlyings/years
        label = labels[i % 4]
        exp_date = start + timedelta(weeks=i)
        noise = rng.normal(0, 0.01, size=5)
        rets = np.array(true_effects[label]) + noise
        rows.append({
            "underlying": "SYN", "expiration_date": exp_date, "signal_label": label,
            "signal_date": exp_date - timedelta(weeks=2),
            "mon_ret": rets[0], "tue_ret": rets[1], "wed_ret": rets[2],
            "thu_ret": rets[3], "fri_ret": rets[4],
            "week_range_pct": abs(rng.normal(0.02, 0.01)),
            "pinned_near_wall": rng.random() < (0.7 if "stable" in label else 0.25),
        })
    history = pd.DataFrame(rows)

    print("=== Conditional Table ===")
    cond_table = build_conditional_table(history)
    pd.set_option("display.width", 160)
    print(cond_table.round(5))

    print("\n=== Significance Tests (FDR-corrected) ===")
    sig = significance_tests(history)
    print(sig.round(5))

    print("\n=== Bootstrap CIs ===")
    boot = bootstrap_table(history)
    print(boot.round(5))

    print("\n=== Out-of-Sample Validation ===")
    oos = validate_out_of_sample(history)
    print(oos.round(5))
