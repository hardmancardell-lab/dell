# Weekly Options Signal + Backtest Toolkit

Two files, deliberately decoupled:

## 1. `signal_engine.py` — "What's the regime right now?"

Takes a **live options chain snapshot** (strikes, OI, volume, IV for one
underlying/expiration) and computes:

- **Net GEX** (dealer gamma exposure) per strike, and the **gamma flip level**
- **Call wall / put wall** (strikes with max positive / most negative GEX)
- **IV term structure** signal (this week's IV vs. a further-dated expiration)
- **Flow ratio** at the walls (volume vs. prior-day OI — is flow opening new
  positions or unwinding?)
- A combined **4-quadrant label**: `bullish-stable`, `bullish-volatile`,
  `bearish-stable`, `bearish-volatile` (direction separated from vol regime,
  per the academic framing rather than a single binary)

Run it standalone: `python3 signal_engine.py` — uses synthetic data to prove
the pipeline works. Swap in a real chain (pandas DataFrame with columns
`strike, right, open_interest, volume, iv`) to use it live.

**Validate this piece first, before touching the backtest.** Concretely:
pull a handful of days you *know* were volatile (earnings, CPI prints, a
known gamma-squeeze day) and a handful you know were quiet, run the chain
through `compute_strike_gex` → `classify_gex_regime`, and confirm the flip
level and regime label match what you already know happened. If it doesn't
line up on known cases, don't proceed to the backtest — fix the signal first.

## 2. `backtest_engine.py` — "Given the regime, what happened historically?"

Takes an **assembled historical table** — one row per underlying per
expiration week, with the signal label already computed 2-3 weeks prior, plus
that week's realized Mon-Fri returns — and produces:

- The day-of-week conditional mean/std table, by signal label
- **T-tests with Benjamini-Hochberg FDR correction** across all label×day
  cells (this is the multiple-comparisons problem flagged earlier — with 4
  labels × 5 days = 20 simultaneous tests, some will look "significant" by
  chance alone; FDR correction is what separates real patterns from noise)
- **Bootstrap confidence intervals** per cell (more robust than a t-test when
  N is small or the distribution isn't clean/normal)
- **Time-based out-of-sample validation** — holds back the most recent ~25%
  of weeks, checks whether the in-sample pattern's sign survives out of
  sample (a flipped sign out-of-sample = overfit, not a real edge)

Run it standalone: `python3 backtest_engine.py` — builds 200 synthetic
expiration weeks with known effects baked in, then shows the pipeline
correctly recovering the strong effects and killing the weak ones.

## How they connect (the piece you have to build yourself)

Neither file fetches real market data — that's intentionally left out since
it depends on whatever data source you have access to (ORATS, CBOE DataShop,
a broker API, Polygon.io, etc.). The missing middle step is:

```
for each underlying in your universe:
    for each historical expiration week:
        1. pull the chain snapshot from 2-3 weeks before that expiration
        2. run it through signal_engine.py -> get signal_label
        3. pull that expiration week's daily OHLC
        4. compute mon_ret..fri_ret, week_range_pct, pinned_near_wall
        5. append one row to your `history` DataFrame
    once you have `history` assembled -> feed it into backtest_engine.py
```

## Reading the results honestly

- If a cell's FDR-adjusted p-value isn't significant, that's not a bug —
  it's the tool doing its job. Most cells in a small sample legitimately
  won't clear significance. Don't cherry-pick the ones that do without also
  reporting how many you tested.
- If a pattern doesn't hold sign out-of-sample, trust the out-of-sample
  result over the in-sample one. In-sample "patterns" in this kind of data
  are cheap to find and expensive to trust.
- Minimum bar before considering this "signal" rather than "noise": passes
  FDR correction in-sample AND holds the same sign out-of-sample AND has a
  bootstrap CI that excludes zero. All three, not one.
