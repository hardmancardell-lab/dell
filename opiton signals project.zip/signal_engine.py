"""
signal_engine.py
=================
Step 1 of the build: standalone GEX / IV term-structure / flow-ratio calculator.

This module answers the question "what is the regime right now?" — it does NOT
yet do the day-of-week historical backtest (that's backtest_engine.py, step 2).
Validate this piece first: does the GEX flip level line up with days you know
were volatile? Does term structure backwardation line up with known events?

Data model
----------
Each "chain snapshot" is a pandas DataFrame with one row per (strike, right)
for a single underlying / single expiration / single point in time, columns:

    strike       float
    right        'C' or 'P'
    open_interest int      (T-1 reported OI, per OCC convention)
    volume       int       (today's volume at that strike/right)
    iv           float     (implied vol, decimal e.g. 0.35)

Plus scalars for that snapshot: spot price, valuation date, expiration date,
risk-free rate (can default to 0 for short-dated equity options; immaterial
here since we only need gamma, not full pricing).
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.stats import norm
from dataclasses import dataclass
from datetime import date


# ---------------------------------------------------------------------------
# Black-Scholes gamma
# ---------------------------------------------------------------------------

def bs_gamma(spot: float, strike: float, T_years: float, sigma: float, r: float = 0.0) -> float:
    """
    Black-Scholes gamma (same formula for calls and puts -- gamma doesn't
    depend on option type, only on S, K, T, sigma, r).

    Returns gamma per $1 move in the underlying, per contract (i.e. per share).
    """
    if T_years <= 0 or sigma <= 0 or spot <= 0 or strike <= 0:
        return 0.0
    d1 = (np.log(spot / strike) + (r + 0.5 * sigma ** 2) * T_years) / (sigma * np.sqrt(T_years))
    return norm.pdf(d1) / (spot * sigma * np.sqrt(T_years))


# ---------------------------------------------------------------------------
# GEX calculation
# ---------------------------------------------------------------------------

def compute_strike_gex(
    chain: pd.DataFrame,
    spot: float,
    valuation_date: date,
    expiration_date: date,
    contract_multiplier: int = 100,
    dealer_short_calls: bool = True,
    dealer_short_puts: bool = False,
) -> pd.DataFrame:
    """
    Compute dollar gamma exposure (GEX) per strike.

    Standard heuristic (flagged as an assumption -- see Glassnode critique in
    prior discussion): dealers are net SHORT calls and net LONG puts against
    customer buying pressure, i.e. customers net buy calls, net sell puts to
    dealers. This is a simplification; it can be wrong for single names with
    unusual flow. Toggle the two flags if you have better information (e.g.
    a options-flow vendor that signs trades by aggressor).

    Sign convention used here (the common "SpotGamma-style" convention):
        Dealer long gamma  -> positive GEX  -> hedging DAMPENS moves
        Dealer short gamma -> negative GEX  -> hedging AMPLIFIES moves

    Under the standard heuristic:
        Calls: dealer is short  -> dealer gamma contribution is NEGATIVE
        Puts:  dealer is long   -> dealer gamma contribution is POSITIVE
    (Some vendors flip this sign convention entirely -- e.g. present call GEX
    as positive because it stabilizes on the way up. Pick one convention and
    be consistent; this function follows the "dealer-signed" convention,
    which is the more mechanistically correct one for interpreting hedging
    direction.)
    """
    T = max((expiration_date - valuation_date).days, 0) / 365.0

    df = chain.copy()
    df["gamma"] = df.apply(
        lambda row: bs_gamma(spot, row["strike"], T, row["iv"]), axis=1
    )

    # dollar gamma per 1% move, scaled by OI and contract multiplier and spot^2
    # standard formalism: dollar_gamma = gamma * spot^2 * 0.01 * OI * multiplier
    df["dollar_gamma"] = df["gamma"] * (spot ** 2) * 0.01 * df["open_interest"] * contract_multiplier

    call_sign = -1 if dealer_short_calls else 1
    put_sign = 1 if dealer_short_puts is False else -1
    # note: dealer_short_puts=False means dealer is LONG puts -> positive sign (matches default above)

    df["dealer_gex"] = np.where(
        df["right"] == "C", df["dollar_gamma"] * call_sign, df["dollar_gamma"] * put_sign
    )

    return df[["strike", "right", "open_interest", "volume", "iv", "gamma", "dollar_gamma", "dealer_gex"]]


def net_gex_by_strike(strike_gex: pd.DataFrame) -> pd.DataFrame:
    """Collapse call+put GEX into net GEX per strike, sorted by strike."""
    out = (
        strike_gex.groupby("strike", as_index=False)["dealer_gex"]
        .sum()
        .rename(columns={"dealer_gex": "net_gex"})
        .sort_values("strike")
        .reset_index(drop=True)
    )
    return out


def find_gamma_flip(net_gex: pd.DataFrame, spot: float) -> float | None:
    """
    Find the strike where net GEX crosses from positive to negative
    (the "zero gamma" / "gamma flip" level), via linear interpolation
    between the two straddling strikes. Returns None if no sign change
    is present in the observed strike range.
    """
    df = net_gex.sort_values("strike").reset_index(drop=True)
    signs = np.sign(df["net_gex"].values)
    for i in range(len(signs) - 1):
        if signs[i] != signs[i + 1] and signs[i] != 0:
            x0, x1 = df["strike"].iloc[i], df["strike"].iloc[i + 1]
            y0, y1 = df["net_gex"].iloc[i], df["net_gex"].iloc[i + 1]
            if y1 == y0:
                continue
            flip = x0 + (0 - y0) * (x1 - x0) / (y1 - y0)
            return float(flip)
    return None


@dataclass
class GexRegime:
    total_net_gex: float
    gamma_flip: float | None
    spot: float
    regime: str          # "positive" or "negative"
    call_wall: float      # strike with max positive GEX
    put_wall: float       # strike with most negative GEX


def classify_gex_regime(net_gex: pd.DataFrame, spot: float) -> GexRegime:
    total = net_gex["net_gex"].sum()
    flip = find_gamma_flip(net_gex, spot)
    call_wall = net_gex.loc[net_gex["net_gex"].idxmax(), "strike"]
    put_wall = net_gex.loc[net_gex["net_gex"].idxmin(), "strike"]
    regime = "positive" if total > 0 else "negative"
    return GexRegime(total, flip, spot, regime, call_wall, put_wall)


# ---------------------------------------------------------------------------
# IV term structure signal
# ---------------------------------------------------------------------------

def term_structure_signal(iv_near: float, iv_far: float) -> dict:
    """
    Compare near-week ATM IV to a further-dated expiration's ATM IV.

    Positive spread (near > far) = backwardation = near-term risk priced up.
    Negative spread (near < far) = contango = normal/complacent term structure.
    """
    spread = iv_near - iv_far
    shape = "backwardation" if spread > 0 else "contango"
    return {"iv_near": iv_near, "iv_far": iv_far, "spread": spread, "shape": shape}


# ---------------------------------------------------------------------------
# Flow ratio (volume vs prior OI) at key strikes
# ---------------------------------------------------------------------------

def flow_ratio_at_strike(volume_today: int, oi_prior_day: int) -> float:
    """
    > 1  : more contracts traded today than existed as OI yesterday -> mostly
           NEW positioning opening.
    < 1  : today's volume is a fraction of existing OI -> more likely existing
           positions being adjusted / closed / rolled.
    """
    if oi_prior_day <= 0:
        return np.nan
    return volume_today / oi_prior_day


def flow_direction_at_walls(strike_gex: pd.DataFrame, regime: GexRegime) -> dict:
    """
    Check whether flow at the call wall and put wall is reinforcing
    (new OI building in the same direction) or unwinding.
    """
    call_row = strike_gex[(strike_gex["strike"] == regime.call_wall) & (strike_gex["right"] == "C")]
    put_row = strike_gex[(strike_gex["strike"] == regime.put_wall) & (strike_gex["right"] == "P")]

    result = {}
    if not call_row.empty:
        r = call_row.iloc[0]
        result["call_wall_flow_ratio"] = flow_ratio_at_strike(r["volume"], r["open_interest"])
    if not put_row.empty:
        r = put_row.iloc[0]
        result["put_wall_flow_ratio"] = flow_ratio_at_strike(r["volume"], r["open_interest"])
    return result


# ---------------------------------------------------------------------------
# Combine into the 4-quadrant classification
# ---------------------------------------------------------------------------

def classify_quadrant(gex_regime: GexRegime, term_signal: dict, flow: dict) -> str:
    """
    4-quadrant label combining direction + volatility regime, per the
    framework discussed: separates DIRECTION from VOL REGIME rather than
    forcing a single bullish/bearish binary.

    Direction proxy: which wall has stronger/reinforcing flow (call wall
    reinforcing -> bullish lean; put wall reinforcing -> bearish lean).
    Vol regime proxy: GEX sign (+term structure as secondary confirmation).
    """
    call_flow = flow.get("call_wall_flow_ratio", np.nan)
    put_flow = flow.get("put_wall_flow_ratio", np.nan)

    # direction: whichever wall shows more NEW opening flow (ratio > 1 and larger)
    call_flow_score = call_flow if not np.isnan(call_flow) else 0
    put_flow_score = put_flow if not np.isnan(put_flow) else 0
    direction = "bullish" if call_flow_score >= put_flow_score else "bearish"

    vol_regime = "stable" if gex_regime.regime == "positive" else "volatile"

    # term structure backwardation nudges toward "volatile" even in positive GEX,
    # since it signals the market is pricing a near-term catalyst
    if term_signal["shape"] == "backwardation" and vol_regime == "stable":
        vol_regime = "volatile"

    return f"{direction}-{vol_regime}"


# ---------------------------------------------------------------------------
# Quick self-test with synthetic data (run: python signal_engine.py)
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    from datetime import date, timedelta

    # --- synthetic option chain for illustration ---
    spot = 100.0
    strikes = np.arange(80, 121, 2.5)
    rows = []
    for k in strikes:
        # more OI clustered near spot, IV smiles slightly
        dist = abs(k - spot)
        base_oi = max(500 - dist * 15, 20)
        iv = 0.25 + 0.002 * dist
        rows.append({"strike": k, "right": "C", "open_interest": int(base_oi * 1.1),
                     "volume": int(base_oi * 0.6), "iv": iv})
        rows.append({"strike": k, "right": "P", "open_interest": int(base_oi * 0.9),
                     "volume": int(base_oi * 0.4), "iv": iv + 0.01})
    chain = pd.DataFrame(rows)

    valuation_date = date(2026, 7, 6)
    expiration_date = date(2026, 7, 11)  # this-week expiry

    strike_gex = compute_strike_gex(chain, spot, valuation_date, expiration_date)
    net_gex = net_gex_by_strike(strike_gex)
    regime = classify_gex_regime(net_gex, spot)

    term = term_structure_signal(iv_near=0.32, iv_far=0.27)  # example: backwardation
    flow = flow_direction_at_walls(strike_gex, regime)
    label = classify_quadrant(regime, term, flow)

    print("=== GEX Regime ===")
    print(regime)
    print("\n=== Term Structure ===")
    print(term)
    print("\n=== Flow at walls ===")
    print(flow)
    print("\n=== FINAL SIGNAL LABEL ===")
    print(label)
